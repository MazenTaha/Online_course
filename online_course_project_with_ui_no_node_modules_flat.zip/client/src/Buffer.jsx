
import React, {{ useState, useEffect }} from 'react';
import api from '../api';

export default function Buffer() {{
  const [items, setItems] = useState([]);
  const [form, setForm] = useState({{} });
  const [msg, setMsg] = useState('');

  const fetchItems = async () => {{
    try{{ const res = await api.get('/buffer'); setItems(res.data.data || res.data || []); }}catch(e){{ setMsg(String(e)); }}
  }};

  useEffect(()=>{{ fetchItems(); }}, []);

  const createItem = async (e) => {{
    e.preventDefault();
    try{{ const res = await api.post('/buffer', form); setMsg(JSON.stringify(res.data)); fetchItems(); }}catch(e){{ setMsg(String(e)); }}
  }};

  return (
    <section className="card">
      <h3>buffer (auto-generated)</h3>
      <form onSubmit={{createItem}} className="form-grid">
        <label>buf: <input value={{form['buf'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'buf': e.target.value}}))}} /></label>
        <label>subtype: <input value={{form['subtype'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'subtype': e.target.value}}))}} /></label>
        <label>test: <input value={{form['test'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'test': e.target.value}}))}} /></label>
        <label>type: <input value={{form['type'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'type': e.target.value}}))}} /></label>
        <label>uuid: <input value={{form['uuid'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'uuid': e.target.value}}))}} /></label>
        <div className="form-actions">
          <button type="submit">Create</button>
          <button type="button" onClick={{fetchItems}}>Refresh</button>
        </div>
      </form>

      <div className="items">
        {{items && items.length ? items.map((it, i)=>(<pre key={{i}}>{{JSON.stringify(it, null, 2)}}</pre>)) : <div className="muted">No items</div>}}
      </div>
      <pre className="response">{{msg}}</pre>
    </section>
  );
}
