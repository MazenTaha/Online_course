import axios from 'axios';
const base = (import.meta.env.VITE_API_BASE || 'http://localhost:3000') + '/api';
const api = axios.create({ baseURL: base });
api.interceptors.request.use(cfg => {
  const token = localStorage.getItem('ocp_token');
  if(token) cfg.headers.Authorization = 'Bearer ' + token;
  return cfg;
});
export default api;
