
import React, {{ useState, useEffect }} from 'react';
import api from '../api';

export default function Schematype() {{
  const [items, setItems] = useState([]);
  const [form, setForm] = useState({{} });
  const [msg, setMsg] = useState('');

  const fetchItems = async () => {{
    try{{ const res = await api.get('/schematype'); setItems(res.data.data || res.data || []); }}catch(e){{ setMsg(String(e)); }}
  }};

  useEffect(()=>{{ fetchItems(); }}, []);

  const createItem = async (e) => {{
    e.preventDefault();
    try{{ const res = await api.post('/schematype', form); setMsg(JSON.stringify(res.data)); fetchItems(); }}catch(e){{ setMsg(String(e)); }}
  }};

  return (
    <section className="card">
      <h3>schematype (auto-generated)</h3>
      <form onSubmit={{createItem}} className="form-grid">
        <label>aNumber: <input value={{form['aNumber'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'aNumber': e.target.value}}))}} /></label>
        <label>age: <input value={{form['age'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'age': e.target.value}}))}} /></label>
        <label>born: <input value={{form['born'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'born': e.target.value}}))}} /></label>
        <label>creditCardNumber: <input value={{form['creditCardNumber'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'creditCardNumber': e.target.value}}))}} /></label>
        <label>date: <input value={{form['date'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'date': e.target.value}}))}} /></label>
        <label>default: <input value={{form['default'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'default': e.target.value}}))}} /></label>
        <label>email: <input value={{form['email'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'email': e.target.value}}))}} /></label>
        <label>expires: <input value={{form['expires'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'expires': e.target.value}}))}} /></label>
        <label>get: <input value={{form['get'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'get': e.target.value}}))}} /></label>
        <label>immutable: <input value={{form['immutable'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'immutable': e.target.value}}))}} /></label>
        <label>index: <input value={{form['index'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'index': e.target.value}}))}} /></label>
        <label>keywords: <input value={{form['keywords'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'keywords': e.target.value}}))}} /></label>
        <div className="form-actions">
          <button type="submit">Create</button>
          <button type="button" onClick={{fetchItems}}>Refresh</button>
        </div>
      </form>

      <div className="items">
        {{items && items.length ? items.map((it, i)=>(<pre key={{i}}>{{JSON.stringify(it, null, 2)}}</pre>)) : <div className="muted">No items</div>}}
      </div>
      <pre className="response">{{msg}}</pre>
    </section>
  );
}
