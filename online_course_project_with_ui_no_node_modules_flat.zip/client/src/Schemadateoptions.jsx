
import React, {{ useState, useEffect }} from 'react';
import api from '../api';

export default function Schemadateoptions() {{
  const [items, setItems] = useState([]);
  const [form, setForm] = useState({{} });
  const [msg, setMsg] = useState('');

  const fetchItems = async () => {{
    try{{ const res = await api.get('/schemadateoptions'); setItems(res.data.data || res.data || []); }}catch(e){{ setMsg(String(e)); }}
  }};

  useEffect(()=>{{ fetchItems(); }}, []);

  const createItem = async (e) => {{
    e.preventDefault();
    try{{ const res = await api.post('/schemadateoptions', form); setMsg(JSON.stringify(res.data)); fetchItems(); }}catch(e){{ setMsg(String(e)); }}
  }};

  return (
    <section className="card">
      <h3>schemadateoptions (auto-generated)</h3>
      <form onSubmit={{createItem}} className="form-grid">
        <label>expireAt: <input value={{form['expireAt'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'expireAt': e.target.value}}))}} /></label>
        <label>expires: <input value={{form['expires'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'expires': e.target.value}}))}} /></label>
        <label>startedAt: <input value={{form['startedAt'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'startedAt': e.target.value}}))}} /></label>
        <label>type: <input value={{form['type'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'type': e.target.value}}))}} /></label>
        <div className="form-actions">
          <button type="submit">Create</button>
          <button type="button" onClick={{fetchItems}}>Refresh</button>
        </div>
      </form>

      <div className="items">
        {{items && items.length ? items.map((it, i)=>(<pre key={{i}}>{{JSON.stringify(it, null, 2)}}</pre>)) : <div className="muted">No items</div>}}
      </div>
      <pre className="response">{{msg}}</pre>
    </section>
  );
}
