
import React, {{ useState, useEffect }} from 'react';
import api from '../api';

export default function Schemaarrayoptions() {{
  const [items, setItems] = useState([]);
  const [form, setForm] = useState({{} });
  const [msg, setMsg] = useState('');

  const fetchItems = async () => {{
    try{{ const res = await api.get('/schemaarrayoptions'); setItems(res.data.data || res.data || []); }}catch(e){{ setMsg(String(e)); }}
  }};

  useEffect(()=>{{ fetchItems(); }}, []);

  const createItem = async (e) => {{
    e.preventDefault();
    try{{ const res = await api.post('/schemaarrayoptions', form); setMsg(JSON.stringify(res.data)); fetchItems(); }}catch(e){{ setMsg(String(e)); }}
  }};

  return (
    <section className="card">
      <h3>schemaarrayoptions (auto-generated)</h3>
      <form onSubmit={{createItem}} className="form-grid">
        <label>arr: <input value={{form['arr'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'arr': e.target.value}}))}} /></label>
        <label>castNonArrays: <input value={{form['castNonArrays'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'castNonArrays': e.target.value}}))}} /></label>
        <label>of: <input value={{form['of'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'of': e.target.value}}))}} /></label>
        <label>tags: <input value={{form['tags'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'tags': e.target.value}}))}} /></label>
        <label>type: <input value={{form['type'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'type': e.target.value}}))}} /></label>
        <label>x1: <input value={{form['x1'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'x1': e.target.value}}))}} /></label>
        <div className="form-actions">
          <button type="submit">Create</button>
          <button type="button" onClick={{fetchItems}}>Refresh</button>
        </div>
      </form>

      <div className="items">
        {{items && items.length ? items.map((it, i)=>(<pre key={{i}}>{{JSON.stringify(it, null, 2)}}</pre>)) : <div className="muted">No items</div>}}
      </div>
      <pre className="response">{{msg}}</pre>
    </section>
  );
}
