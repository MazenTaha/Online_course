
import React, {{ useState, useEffect }} from 'react';
import api from '../api';

export default function Date() {{
  const [items, setItems] = useState([]);
  const [form, setForm] = useState({{} });
  const [msg, setMsg] = useState('');

  const fetchItems = async () => {{
    try{{ const res = await api.get('/date'); setItems(res.data.data || res.data || []); }}catch(e){{ setMsg(String(e)); }}
  }};

  useEffect(()=>{{ fetchItems(); }}, []);

  const createItem = async (e) => {{
    e.preventDefault();
    try{{ const res = await api.post('/date', form); setMsg(JSON.stringify(res.data)); fetchItems(); }}catch(e){{ setMsg(String(e)); }}
  }};

  return (
    <section className="card">
      <h3>date (auto-generated)</h3>
      <form onSubmit={{createItem}} className="form-grid">
        <label>createdAt: <input value={{form['createdAt'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'createdAt': e.target.value}}))}} /></label>
        <label>d: <input value={{form['d'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'d': e.target.value}}))}} /></label>
        <label>date: <input value={{form['date'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'date': e.target.value}}))}} /></label>
        <label>default: <input value={{form['default'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'default': e.target.value}}))}} /></label>
        <label>expires: <input value={{form['expires'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'expires': e.target.value}}))}} /></label>
        <label>max: <input value={{form['max'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'max': e.target.value}}))}} /></label>
        <label>min: <input value={{form['min'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'min': e.target.value}}))}} /></label>
        <label>test: <input value={{form['test'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'test': e.target.value}}))}} /></label>
        <label>type: <input value={{form['type'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'type': e.target.value}}))}} /></label>
        <div className="form-actions">
          <button type="submit">Create</button>
          <button type="button" onClick={{fetchItems}}>Refresh</button>
        </div>
      </form>

      <div className="items">
        {{items && items.length ? items.map((it, i)=>(<pre key={{i}}>{{JSON.stringify(it, null, 2)}}</pre>)) : <div className="muted">No items</div>}}
      </div>
      <pre className="response">{{msg}}</pre>
    </section>
  );
}
