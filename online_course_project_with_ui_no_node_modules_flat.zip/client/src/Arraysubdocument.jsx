
import React, {{ useState, useEffect }} from 'react';
import api from '../api';

export default function Arraysubdocument() {{
  const [items, setItems] = useState([]);
  const [form, setForm] = useState({{} });
  const [msg, setMsg] = useState('');

  const fetchItems = async () => {{
    try{{ const res = await api.get('/arraysubdocument'); setItems(res.data.data || res.data || []); }}catch(e){{ setMsg(String(e)); }}
  }};

  useEffect(()=>{{ fetchItems(); }}, []);

  const createItem = async (e) => {{
    e.preventDefault();
    try{{ const res = await api.post('/arraysubdocument', form); setMsg(JSON.stringify(res.data)); fetchItems(); }}catch(e){{ setMsg(String(e)); }}
  }};

  return (
    <section className="card">
      <h3>arraysubdocument (auto-generated)</h3>
      <form onSubmit={{createItem}} className="form-grid">
        <label>docArr: <input value={{form['docArr'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'docArr': e.target.value}}))}} /></label>
        <label>name: <input value={{form['name'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'name': e.target.value}}))}} /></label>
        <div className="form-actions">
          <button type="submit">Create</button>
          <button type="button" onClick={{fetchItems}}>Refresh</button>
        </div>
      </form>

      <div className="items">
        {{items && items.length ? items.map((it, i)=>(<pre key={{i}}>{{JSON.stringify(it, null, 2)}}</pre>)) : <div className="muted">No items</div>}}
      </div>
      <pre className="response">{{msg}}</pre>
    </section>
  );
}
