
import React, {{ useState, useEffect }} from 'react';
import api from '../api';

export default function String() {{
  const [items, setItems] = useState([]);
  const [form, setForm] = useState({{} });
  const [msg, setMsg] = useState('');

  const fetchItems = async () => {{
    try{{ const res = await api.get('/string'); setItems(res.data.data || res.data || []); }}catch(e){{ setMsg(String(e)); }}
  }};

  useEffect(()=>{{ fetchItems(); }}, []);

  const createItem = async (e) => {{
    e.preventDefault();
    try{{ const res = await api.post('/string', form); setMsg(JSON.stringify(res.data)); fetchItems(); }}catch(e){{ setMsg(String(e)); }}
  }};

  return (
    <section className="card">
      <h3>string (auto-generated)</h3>
      <form onSubmit={{createItem}} className="form-grid">
        <label>caps: <input value={{form['caps'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'caps': e.target.value}}))}} /></label>
        <label>email: <input value={{form['email'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'email': e.target.value}}))}} /></label>
        <label>enum: <input value={{form['enum'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'enum': e.target.value}}))}} /></label>
        <label>file: <input value={{form['file'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'file': e.target.value}}))}} /></label>
        <label>lowercase: <input value={{form['lowercase'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'lowercase': e.target.value}}))}} /></label>
        <label>match: <input value={{form['match'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'match': e.target.value}}))}} /></label>
        <label>maxlength: <input value={{form['maxlength'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'maxlength': e.target.value}}))}} /></label>
        <label>minlength: <input value={{form['minlength'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'minlength': e.target.value}}))}} /></label>
        <label>name: <input value={{form['name'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'name': e.target.value}}))}} /></label>
        <label>postalCode: <input value={{form['postalCode'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'postalCode': e.target.value}}))}} /></label>
        <label>required: <input value={{form['required'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'required': e.target.value}}))}} /></label>
        <label>state: <input value={{form['state'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'state': e.target.value}}))}} /></label>
        <div className="form-actions">
          <button type="submit">Create</button>
          <button type="button" onClick={{fetchItems}}>Refresh</button>
        </div>
      </form>

      <div className="items">
        {{items && items.length ? items.map((it, i)=>(<pre key={{i}}>{{JSON.stringify(it, null, 2)}}</pre>)) : <div className="muted">No items</div>}}
      </div>
      <pre className="response">{{msg}}</pre>
    </section>
  );
}
