
import React, {{ useState, useEffect }} from 'react';
import api from '../api';

export default function Schematypeoptions() {{
  const [items, setItems] = useState([]);
  const [form, setForm] = useState({{} });
  const [msg, setMsg] = useState('');

  const fetchItems = async () => {{
    try{{ const res = await api.get('/schematypeoptions'); setItems(res.data.data || res.data || []); }}catch(e){{ setMsg(String(e)); }}
  }};

  useEffect(()=>{{ fetchItems(); }}, []);

  const createItem = async (e) => {{
    e.preventDefault();
    try{{ const res = await api.post('/schematypeoptions', form); setMsg(JSON.stringify(res.data)); fetchItems(); }}catch(e){{ setMsg(String(e)); }}
  }};

  return (
    <section className="card">
      <h3>schematypeoptions (auto-generated)</h3>
      <form onSubmit={{createItem}} className="form-grid">
        <label>cast: <input value={{form['cast'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'cast': e.target.value}}))}} /></label>
        <label>name: <input value={{form['name'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'name': e.target.value}}))}} /></label>
        <label>num: <input value={{form['num'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'num': e.target.value}}))}} /></label>
        <label>type: <input value={{form['type'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'type': e.target.value}}))}} /></label>
        <div className="form-actions">
          <button type="submit">Create</button>
          <button type="button" onClick={{fetchItems}}>Refresh</button>
        </div>
      </form>

      <div className="items">
        {{items && items.length ? items.map((it, i)=>(<pre key={{i}}>{{JSON.stringify(it, null, 2)}}</pre>)) : <div className="muted">No items</div>}}
      </div>
      <pre className="response">{{msg}}</pre>
    </section>
  );
}
