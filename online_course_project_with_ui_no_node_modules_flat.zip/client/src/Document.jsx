
import React, {{ useState, useEffect }} from 'react';
import api from '../api';

export default function Document() {{
  const [items, setItems] = useState([]);
  const [form, setForm] = useState({{} });
  const [msg, setMsg] = useState('');

  const fetchItems = async () => {{
    try{{ const res = await api.get('/document'); setItems(res.data.data || res.data || []); }}catch(e){{ setMsg(String(e)); }}
  }};

  useEffect(()=>{{ fetchItems(); }}, []);

  const createItem = async (e) => {{
    e.preventDefault();
    try{{ const res = await api.post('/document', form); setMsg(JSON.stringify(res.data)); fetchItems(); }}catch(e){{ setMsg(String(e)); }}
  }};

  return (
    <section className="card">
      <h3>document (auto-generated)</h3>
      <form onSubmit={{createItem}} className="form-grid">
        <label>age: <input value={{form['age'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'age': e.target.value}}))}} /></label>
        <label>bar: <input value={{form['bar'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'bar': e.target.value}}))}} /></label>
        <label>counter: <input value={{form['counter'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'counter': e.target.value}}))}} /></label>
        <label>country: <input value={{form['country'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'country': e.target.value}}))}} /></label>
        <label>email: <input value={{form['email'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'email': e.target.value}}))}} /></label>
        <label>foo: <input value={{form['foo'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'foo': e.target.value}}))}} /></label>
        <label>id: <input value={{form['id'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'id': e.target.value}}))}} /></label>
        <label>members: <input value={{form['members'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'members': e.target.value}}))}} /></label>
        <label>name: <input value={{form['name'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'name': e.target.value}}))}} /></label>
        <label>nested: <input value={{form['nested'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'nested': e.target.value}}))}} /></label>
        <label>timestamps: <input value={{form['timestamps'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'timestamps': e.target.value}}))}} /></label>
        <div className="form-actions">
          <button type="submit">Create</button>
          <button type="button" onClick={{fetchItems}}>Refresh</button>
        </div>
      </form>

      <div className="items">
        {{items && items.length ? items.map((it, i)=>(<pre key={{i}}>{{JSON.stringify(it, null, 2)}}</pre>)) : <div className="muted">No items</div>}}
      </div>
      <pre className="response">{{msg}}</pre>
    </section>
  );
}
