
import React, {{ useState, useEffect }} from 'react';
import api from '../api';

export default function Query() {{
  const [items, setItems] = useState([]);
  const [form, setForm] = useState({{} });
  const [msg, setMsg] = useState('');

  const fetchItems = async () => {{
    try{{ const res = await api.get('/query'); setItems(res.data.data || res.data || []); }}catch(e){{ setMsg(String(e)); }}
  }};

  useEffect(()=>{{ fetchItems(); }}, []);

  const createItem = async (e) => {{
    e.preventDefault();
    try{{ const res = await api.post('/query', form); setMsg(JSON.stringify(res.data)); fetchItems(); }}catch(e){{ setMsg(String(e)); }}
  }};

  return (
    <section className="card">
      <h3>query (auto-generated)</h3>
      <form onSubmit={{createItem}} className="form-grid">
        <label>bar: <input value={{form['bar'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'bar': e.target.value}}))}} /></label>
        <label>email: <input value={{form['email'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'email': e.target.value}}))}} /></label>
        <label>foo: <input value={{form['foo'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'foo': e.target.value}}))}} /></label>
        <label>name: <input value={{form['name'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'name': e.target.value}}))}} /></label>
        <label>num: <input value={{form['num'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'num': e.target.value}}))}} /></label>
        <label>password: <input value={{form['password'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'password': e.target.value}}))}} /></label>
        <label>passwordHash: <input value={{form['passwordHash'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'passwordHash': e.target.value}}))}} /></label>
        <label>required: <input value={{form['required'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'required': e.target.value}}))}} /></label>
        <label>select: <input value={{form['select'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'select': e.target.value}}))}} /></label>
        <label>type: <input value={{form['type'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'type': e.target.value}}))}} /></label>
        <div className="form-actions">
          <button type="submit">Create</button>
          <button type="button" onClick={{fetchItems}}>Refresh</button>
        </div>
      </form>

      <div className="items">
        {{items && items.length ? items.map((it, i)=>(<pre key={{i}}>{{JSON.stringify(it, null, 2)}}</pre>)) : <div className="muted">No items</div>}}
      </div>
      <pre className="response">{{msg}}</pre>
    </section>
  );
}
