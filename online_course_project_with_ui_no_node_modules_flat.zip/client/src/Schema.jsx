
import React, {{ useState, useEffect }} from 'react';
import api from '../api';

export default function Schema() {{
  const [items, setItems] = useState([]);
  const [form, setForm] = useState({{} });
  const [msg, setMsg] = useState('');

  const fetchItems = async () => {{
    try{{ const res = await api.get('/schema'); setItems(res.data.data || res.data || []); }}catch(e){{ setMsg(String(e)); }}
  }};

  useEffect(()=>{{ fetchItems(); }}, []);

  const createItem = async (e) => {{
    e.preventDefault();
    try{{ const res = await api.post('/schema', form); setMsg(JSON.stringify(res.data)); fetchItems(); }}catch(e){{ setMsg(String(e)); }}
  }};

  return (
    <section className="card">
      <h3>schema (auto-generated)</h3>
      <form onSubmit={{createItem}} className="form-grid">
        <label>_id: <input value={{form['_id'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'_id': e.target.value}}))}} /></label>
        <label>a: <input value={{form['a'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'a': e.target.value}}))}} /></label>
        <label>age: <input value={{form['age'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'age': e.target.value}}))}} /></label>
        <label>arr: <input value={{form['arr'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'arr': e.target.value}}))}} /></label>
        <label>autoIndex: <input value={{form['autoIndex'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'autoIndex': e.target.value}}))}} /></label>
        <label>children: <input value={{form['children'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'children': e.target.value}}))}} /></label>
        <label>color: <input value={{form['color'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'color': e.target.value}}))}} /></label>
        <label>created: <input value={{form['created'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'created': e.target.value}}))}} /></label>
        <label>email: <input value={{form['email'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'email': e.target.value}}))}} /></label>
        <label>foo: <input value={{form['foo'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'foo': e.target.value}}))}} /></label>
        <label>id: <input value={{form['id'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'id': e.target.value}}))}} /></label>
        <label>index: <input value={{form['index'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'index': e.target.value}}))}} /></label>
        <div className="form-actions">
          <button type="submit">Create</button>
          <button type="button" onClick={{fetchItems}}>Refresh</button>
        </div>
      </form>

      <div className="items">
        {{items && items.length ? items.map((it, i)=>(<pre key={{i}}>{{JSON.stringify(it, null, 2)}}</pre>)) : <div className="muted">No items</div>}}
      </div>
      <pre className="response">{{msg}}</pre>
    </section>
  );
}
