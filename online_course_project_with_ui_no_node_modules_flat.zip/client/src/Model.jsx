
import React, {{ useState, useEffect }} from 'react';
import api from '../api';

export default function Model() {{
  const [items, setItems] = useState([]);
  const [form, setForm] = useState({{} });
  const [msg, setMsg] = useState('');

  const fetchItems = async () => {{
    try{{ const res = await api.get('/model'); setItems(res.data.data || res.data || []); }}catch(e){{ setMsg(String(e)); }}
  }};

  useEffect(()=>{{ fetchItems(); }}, []);

  const createItem = async (e) => {{
    e.preventDefault();
    try{{ const res = await api.post('/model', form); setMsg(JSON.stringify(res.data)); fetchItems(); }}catch(e){{ setMsg(String(e)); }}
  }};

  return (
    <section className="card">
      <h3>model (auto-generated)</h3>
      <form onSubmit={{createItem}} className="form-grid">
        <label>boss: <input value={{form['boss'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'boss': e.target.value}}))}} /></label>
        <label>breed: <input value={{form['breed'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'breed': e.target.value}}))}} /></label>
        <label>description: <input value={{form['description'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'description': e.target.value}}))}} /></label>
        <label>name: <input value={{form['name'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'name': e.target.value}}))}} /></label>
        <label>pet: <input value={{form['pet'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'pet': e.target.value}}))}} /></label>
        <label>ref: <input value={{form['ref'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'ref': e.target.value}}))}} /></label>
        <label>thing: <input value={{form['thing'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'thing': e.target.value}}))}} /></label>
        <label>timestamps: <input value={{form['timestamps'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'timestamps': e.target.value}}))}} /></label>
        <label>type: <input value={{form['type'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'type': e.target.value}}))}} /></label>
        <label>unique: <input value={{form['unique'] || ''}} onChange={{e=>setForm(Object.assign({{}}, form, {{'unique': e.target.value}}))}} /></label>
        <div className="form-actions">
          <button type="submit">Create</button>
          <button type="button" onClick={{fetchItems}}>Refresh</button>
        </div>
      </form>

      <div className="items">
        {{items && items.length ? items.map((it, i)=>(<pre key={{i}}>{{JSON.stringify(it, null, 2)}}</pre>)) : <div className="muted">No items</div>}}
      </div>
      <pre className="response">{{msg}}</pre>
    </section>
  );
}
