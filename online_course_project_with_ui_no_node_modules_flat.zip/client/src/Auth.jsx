import React, {useState} from 'react';
import api from './api';
export default function Auth(){ 
  const [mode, setMode] = useState('signup');
  const [form, setForm] = useState({});
  const [msg, setMsg] = useState('');
  const submit = async (e)=>{
    e.preventDefault();
    try{
      const url = mode==='signup' ? '/auth/signup' : '/auth/login';
      const res = await api.post(url, form);
      setMsg(JSON.stringify(res.data));
      if(res.data.token){ localStorage.setItem('ocp_token', res.data.token); setMsg('Logged in — token saved'); }
    }catch(e){ setMsg(String(e)); }
  };
  return (
    <section className="card">
      <h3>Auth</h3>
      <div className="tabs">
        <button onClick={()=>setMode('signup')} className={mode==='signup'?'active':''}>Sign Up</button>
        <button onClick={()=>setMode('login')} className={mode==='login'?'active':''}>Login</button>
      </div>
      <form onSubmit={submit} className="form-grid">
        <label>username: <input onChange={e=>setForm({...form, username: e.target.value})} /></label>
        <label>email: <input onChange={e=>setForm({...form, email: e.target.value})} /></label>
        <label>password: <input type="password" onChange={e=>setForm({...form, password: e.target.value})} /></label>
        <div className="form-actions"><button type="submit">{mode==='signup'?'Sign Up':'Login'}</button></div>
      </form>
      <pre className="response">{msg}</pre>
    </section>
  );
}
