const express = require("express");
const morgan = require("morgan");
const dotenv = require("dotenv");
const cors = require("cors");
const { protect, restrictTo } = require("./controllers/authController");
const userRouter = require("./routes/userRoutes");
const enrollmentRouter = require("./routes/enrollmentRoute");
const certificateRouter = require("./routes/certificateRoutes");
const courseRouter = require("./routes/coursesRoutes");
const quizRouter = require("./routes/quizRoutes");
const assignmentRouter = require("./routes/assignmentRoutes");
const receiveRouter = require("./routes/recieveRoutes");
const authRouter = require("./routes/authRoutes");

dotenv.config({ path: "./.env" });

const app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(morgan("dev"));
app.use(cors());
app.use("/api/auth", authRouter);
app.use("/api/user", protect, restrictTo("admin"), userRouter);
app.use("/api/enrollment", protect, enrollmentRouter);
app.use("/api/certificate", protect, restrictTo("admin"), certificateRouter);
app.use("/api/courses", protect, restrictTo("admin"), courseRouter);
app.use("/api/quiz", protect, quizRouter); // Removed restrictTo("instructor") for flexibility
app.use("/api/assignment", protect, assignmentRouter);
app.use("/api/receive", receiveRouter);
const studentEnrollmentRouter = require("./routes/studentEnrollmentRoutes");
app.use("/api/student", studentEnrollmentRouter);
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(err.statusCode || 500).json({ status: err.status || "error", message: err.message });
});
// app.use(express.json({ limit: '10kb' }));
// app.use((req, res, next) => {
//   console.log('Request Body:', req.body);
//   next();
// });
module.exports = app;