const express = require("express");
const router = express.Router();
const receiveController = require("../controllers/receiveController");
const certificateController = require("../controllers/certificateController");
const { protect, restrictTo } = require("../controllers/authController");

router.post("/receive", protect, restrictTo("admin"), receiveController.receiveCertificate);

module.exports = router;