const express = require("express");
const { protect, restrictTo } = require("../controllers/authController");
const {
  getAllCertificates,
  createCertificate,
  deleteCertificate,
} = require("../controllers/certificateController");

const router = express.Router();

router.use(protect);
router.use(restrictTo("admin"));

// router.route("/").get(getAllCertificates)
router.get('/',getAllCertificates);
router.post("/createCertificate", createCertificate);

// router.route("/:id")
//   .delete(deleteCertificate);
router.delete("/:id",deleteCertificate);
module.exports = router;