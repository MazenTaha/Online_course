const express = require("express");
const { createEnrollment } = require("../controllers/studentEnrollment");
const { protect, restrictTo } = require("../controllers/authController");

const router = express.Router();

router.post("/enroll", protect, restrictTo("student"), createEnrollment);

module.exports = router;