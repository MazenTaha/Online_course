// const express = require("express");
// const {
//   createEnrollment,
//   getAllEnrollments,
//   getEnrollmentById,
//   enrollStudent,
// } = require("../controllers/enrollmentController");
// const { protect } = require("../controllers/authController");

// const enrollmentRouter = express.Router();
// enrollmentRouter.get("/", getAllEnrollments);
// enrollmentRouter.get("/:id", getEnrollmentById);
// enrollmentRouter.post("/", protect, createEnrollment);
// // enrollmentRouter.post("/enroll", protect, enrollStudent);
// module.exports = enrollmentRouter;

const express = require("express");
const {
  createEnrollment,
  getAllEnrollments,
  getEnrollmentById,
  enrollStudent,
  updateEnrollment,
} = require("../controllers/enrollmentController");
const { protect } = require("../controllers/authController");

const enrollmentRouter = express.Router();
enrollmentRouter.get("/", getAllEnrollments);
enrollmentRouter.get("/:id", getEnrollmentById);
enrollmentRouter.post("/", protect, createEnrollment);
// enrollmentRouter.post("/enroll", protect, enrollStudent);
enrollmentRouter.patch("/:id", protect, updateEnrollment);
module.exports = enrollmentRouter;