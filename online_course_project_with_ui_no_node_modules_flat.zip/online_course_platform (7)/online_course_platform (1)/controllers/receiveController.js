// const Receive = require("../model/receiveModel");
// const Certificate = require("../model/certificateModel");
// const User = require("../model/userModel");
// const AppError = require("../utils/appError");
// const { catchAsync } = require("../utils/catchAsync");
// const Enrollment = require("../model/enrollmentModel")

// exports.receiveCertificate = catchAsync(async (req, res, next) => {
//   const { studentId, certificateId } = req.body;

//   const student = await User.findById(studentId);
//   if (!student) return next(new AppError("Student not found", 404));
//   const certificate = await Certificate.findById(certificateId);
//   if (!certificate) return next(new AppError("Certificate not found", 404));

//   const receive = await Receive.create({
//     student: studentId,
//     certificate: certificateId,
//   });
// const enrollment = await Enrollment.findOne({ student, certificate });

//   if (!enrollment) {
//     return next(new AppError("Student is not enrolled in this course", 404));
//   }


//   if (enrollment.status !== "completed" || enrollment.grade < 60) {
//     return next(
//       new AppError("Student must complete the course and pass with at least 60% to receive a certificate", 400)
//     );
//   }

 
//   const received = await Receive.create({ student, certificate });

//   res.status(201).json({
//     message: "Certificate received successfully",
//     data: received,
//   });
// });
//----------------------------------------------------
//   res.status(201).json({
//     status: "success",
//     data: {
//       receive,
//     },
//   });
// //new code
// // const Receive = require("../model/receiveModel");
// // const Certificate = require("../model/certificateModel");
// // const User = require("../model/userModel");
// // const AppError = require("../utils/appError");
// // const { catchAsync } = require("../utils/catchAsync");

// // exports.receiveCertificate = catchAsync(async (req, res, next) => {
// //   const { certificateId } = req.body;
// //   const studentId = req.user._id; // Use authenticated user's ID from protect middleware

// //   // Verify student exists
// //   const student = await User.findById(studentId);
// //   if (!student) return next(new AppError("Student not found", 404));

// //   // Verify certificate exists and populate course
// //   const certificate = await Certificate.findById(certificateId).populate('course');
// //   if (!certificate) return next(new AppError("Certificate not found", 404));
// //   const course = certificate.course;

// //   // Check enrollment status
// //   const enrollment = await Enrollment.findOne({ student: studentId, course: course._id });
// //   if (!enrollment) {
// //     return next(new AppError("Student is not enrolled in this course", 404));
// //   }

// //   // Validate completion and grade
// //   if (enrollment.status !== "completed" || enrollment.grade < 60) {
// //     return next(
// //       new AppError("Student must complete the course and pass with at least 60% to receive a certificate", 400)
// //     );
// //   }

// //   // Create receive record
// //   const receive = await Receive.create({
// //     student: studentId,
// //     certificate: certificateId,
// //   });

// //   // Respond with success
// //   res.status(201).json({
// //     message: "Certificate received successfully",
// //     data: receive,
// //   });
// // });

// //latest 
// const Receive = require("../model/receiveModel");
// const Certificate = require("../model/certificateModel");
// const User = require("../model/userModel");
// const AppError = require("../utils/appError");
// const { catchAsync } = require("../utils/catchAsync");

// exports.receiveCertificate = catchAsync(async (req, res, next) => {
//   const { certificateId } = req.body;
//   const studentId = req.user._id; // Use authenticated user's ID from protect middleware

//   // Log input for debugging
//   console.log('Student ID:', studentId, 'Certificate ID:', certificateId);

//   // Verify student exists
//   const student = await User.findById(studentId);
//   if (!student) return next(new AppError("Student not found", 404));

//   // Verify certificate exists and populate course
//   const certificate = await Certificate.findById(certificateId).populate('course');
//   // Log query result for debugging
//   console.log('Certificate Query Result:', certificate);
//   if (!certificate) return next(new AppError("Certificate not found", 404));
//   const course = certificate.course;

//   // Check enrollment status
//   const enrollment = await Enrollment.findOne({ student: studentId, course: course._id });
//   if (!enrollment) {
//     return next(new AppError("Student is not enrolled in this course", 404));
//   }

//   // Validate completion and grade
//   if (enrollment.status !== "completed" || enrollment.grade < 60) {
//     return next(
//       new AppError("Student must complete the course and pass with at least 60% to receive a certificate", 400)
//     );
//   }

//   // Create receive record
//   const receive = await Receive.create({
//     student: studentId,
//     certificate: certificateId,
//   });

//   // Respond with success
//   res.status(201).json({
//     message: "Certificate received successfully",
//     data: receive,
//   });
// });
//edited
// const Receive = require("../model/receiveModel");
// const Certificate = require("../model/certificateModel");
// const User = require("../model/userModel");
// const AppError = require("../utils/appError");
// const { catchAsync } = require("../utils/catchAsync");

// exports.receiveCertificate = catchAsync(async (req, res, next) => {
//   const { certificateId } = req.body;
//   const studentId = req.user._id; // Use authenticated user's ID from protect middleware

//   // Log input for debugging
//   console.log('Student ID:', studentId, 'Certificate ID:', certificateId);

//   // Validate certificateId is provided
//   if (!certificateId) {
//     return next(new AppError("Certificate ID is required", 400));
//   }

//   // Verify student exists
//   const student = await User.findById(studentId);
//   if (!student) return next(new AppError("Student not found", 404));

//   // Verify certificate exists and populate course
//   const certificate = await Certificate.findById(certificateId).populate('course');
//   // Log query result for debugging
//   console.log('Certificate Query Result:', certificate);
//   if (!certificate) return next(new AppError("Certificate not found", 404));
//   const course = certificate.course;

//   // Check enrollment status
//   const enrollment = await Enrollment.findOne({ student: studentId, course: course._id });
//   if (!enrollment) {
//     return next(new AppError("Student is not enrolled in this course", 404));
//   }

//   // Validate completion and grade
//   if (enrollment.status !== "completed" || enrollment.grade < 60) {
//     return next(
//       new AppError("Student must complete the course and pass with at least 60% to receive a certificate", 400)
//     );
//   }

//   // Create receive record
//   const receive = await Receive.create({
//     student: studentId,
//     certificate: certificateId,
//   });

//   // Respond with success
//   res.status(201).json({
//     message: "Certificate received successfully",
//     data: receive,
//   });
// });

//try
// const Receive = require("../model/receiveModel");
// const Certificate = require("../model/certificateModel");
// const User = require("../model/userModel");
// const Enrollment = require("../model/enrollmentModel");
// const AppError = require("../utils/appError");
// const { catchAsync } = require("../utils/catchAsync");

// exports.receiveCertificate = catchAsync(async (req, res, next) => {
//   const { studentId, courseIdId } = req.body;

//   console.log('Admin ID:', req.user._id, 'User ID:', studentId, 'course ID:', courseId);

//   if (!studentId || !certificateId) {
//     return next(new AppError("User ID and Certificate ID are required", 400));
//   }

//   if (req.user.role !== "admin") {
//     return next(new AppError("Only admins can issue certificates", 403));
//   }

//   const user = await User.findById(studentId);
//   if (!user) return next(new AppError("User not found", 404));
//   if (user.role !== "student") {
//     return next(new AppError("Only students can receive certificates", 403));
//   }

//   const certificate = await Certificate.findById(certificateId);
//   console.log('Certificate Query Result:', certificate);
//   if (!certificate) return next(new AppError("Certificate not found", 404));

//   // Optional: Check if certificate is already assigned to a different user
//   if (certificate.studentId && certificate.studentId.toString() !== studentId) {
//     return next(new AppError("Certificate is already assigned to another user", 400));
//   }

//   const courseId = certificate.courseId;
//   if (!courseId) {
//     return next(new AppError("Certificate has no associated course", 400));
//   }

//   const enrollment = await Enrollment.findOne({ student: studentId, course: courseId });
//   if (!enrollment) {
//     return next(new AppError("User is not enrolled in this course", 404));
//   }

//   if (enrollment.status !== "completed" || enrollment.grade < 60) {
//     return next(
//       new AppError("User must complete the course and pass with at least 60% to receive a certificate", 400)
//     );
//   }

//   if (!certificate.studentId) {
//     certificate.studentId = studentId;
//     await certificate.save();
//   }

//   const receive = await Receive.create({
//     student: studentId,
//     certificate: certificateId,
//   });

//   res.status(201).json({
//     message: "Certificate issued successfully by admin",
//     data: receive,
//   });
// });
//trying
// 

//new
const Receive = require("../model/receiveModel");
const Certificate = require("../model/certificateModel");
const User = require("../model/userModel");
const Enrollment = require("../model/enrollmentModel");
const AppError = require("../utils/appError");
const { catchAsync } = require("../utils/catchAsync");

exports.receiveCertificate = catchAsync(async (req, res, next) => {
  const { studentId, courseId } = req.body;

  console.log("Admin ID:", req.user._id, "Student ID:", studentId, "Course ID:", courseId);

  if (!studentId || !courseId) {
    return next(new AppError("Student ID and Course ID are required", 400));
  }

  if (req.user.role !== "admin") {
    return next(new AppError("Only admins can issue certificates", 403));
  }

  const student = await User.findById(studentId);
  if (!student) return next(new AppError("User not found", 404));
  if (student.role !== "student") {
    return next(new AppError("Only students can receive certificates", 403));
  }

  // Find certificate associated with the given course
  const certificate = await Certificate.findOne({ courseId });
  console.log("Certificate Query Result:", certificate);
  if (!certificate) return next(new AppError("Certificate not found for this course", 404));

  // Ensure it's not already assigned
  if (certificate.studentId && certificate.studentId.toString() !== studentId) {
    return next(new AppError("Certificate is already assigned to another student", 400));
  }

  // Check enrollment
  const enrollment = await Enrollment.findOne({ student: studentId, course: courseId });
  if (!enrollment) {
    return next(new AppError("Student is not enrolled in this course", 404));
  }

  if (enrollment.status !== "completed" || enrollment.grade < 60) {
    return next(
      new AppError("Student must complete the course and pass with at least 60% to receive a certificate", 400)
    );
  }

  // Assign certificate to student
  if (!certificate.studentId) {
    certificate.studentId = studentId;
    await certificate.save();
  }

  const receive = await Receive.create({
    student: studentId,
    certificate: certificate._id,
  });

  res.status(201).json({
    message: "Certificate issued successfully by admin",
    data: receive,
  });
});


//------------------------------------------
// controllers/receiveController.js
// const Certificate = require("../model/certificateModel");
// const Course = require("../model/courseModel");
// const Enrollment = require("../model/enrollmentModel");

// exports.receiveCertificate = async (req, res) => {
//   try {
//     const { studentId, courseId } = req.body;

//     // 1️⃣ Check if the student is enrolled in the course
//     const enrollment = await Enrollment.findOne({ studentId, courseId });

//     if (!enrollment) {
//       return res.status(400).json({
//         status: "fail",
//         message: "Student is not enrolled in this course",
//       });
//     }

//     // 2️⃣ Create the certificate
//     const certificate = await Certificate.create({
//       studentId,
//       courseId,
//       dateIssued: new Date(),
//     });

//     // 3️⃣ Response
//     res.status(201).json({
//       status: "success",
//       data: {
//         certificate,
//       },
//     });

//   } catch (err) {
//     res.status(500).json({
//       status: "error",
//       message: err.message,
//     });
//   }
// };
