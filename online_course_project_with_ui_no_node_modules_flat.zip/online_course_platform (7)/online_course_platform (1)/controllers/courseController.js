const Course = require("../model/courseModel");
const { catchAsync } = require("../utils/catchAsync");

exports.getAllCourses = catchAsync(async (req, res, next) => {
  const courses = await Course.find().populate("instructorId");
  res.status(200).json({ message: "success", data: courses });
});

exports.createCourse = catchAsync(async (req, res, next) => {
  const newCourse = await Course.create({ ...req.body, instructorId: req.user._id });
  res.status(201).json({ message: "created", data: newCourse });
});

exports.updateCourse = catchAsync(async (req, res, next) => {
  const course = await Course.findByIdAndUpdate(req.params.id, req.body, { new: true }).populate("instructorId");
  if (!course) return next(new AppError("Course not found to update", 404));
  res.status(200).json({ message: "updated", data: course });
});

exports.deleteCourse = catchAsync(async (req, res, next) => {
  const course = await Course.findByIdAndDelete(req.params.id);
  if (!course) return next(new AppError("Course not found", 404));
  res.status(204).json({ message: "deleted" });
});