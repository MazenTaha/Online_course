// const Certificate = require("../model/certificateModel");
// const { catchAsync } = require("../utils/catchAsync");
// const { protect, restrictTo } = require("./authController");

// exports.getAllCertificates = catchAsync(async (req, res, next) => {
//   const certs = await Certificate.find();
//   res.status(200).json({ message: "success", data: certs });
// });

// exports.createCertificate = catchAsync(async (req, res, next) => {
//   const { courseId } = req.body;
//   if ( !courseId) return next(new AppError("Course ID are required", 400));
//   const newCert = await Certificate.create({ ...req.body, courseId });
//   res.status(201).json({ message: "created", data: newCert });
// });

// exports.deleteCertificate = catchAsync(async (req, res, next) => {
//   await Certificate.findByIdAndDelete(req.params.id);
//   res.status(204).json({ message: "deleted" });
// });

//new
// const Certificate = require("../model/certificateModel");
// const AppError = require("../utils/appError"); // Add this
// const { catchAsync } = require("../utils/catchAsync");
// const { protect, restrictTo } = require("./authController");

// exports.getAllCertificates = catchAsync(async (req, res, next) => {
//   const certs = await Certificate.find();
//   res.status(200).json({ message: "success", data: certs });
// });

// exports.createCertificate = catchAsync(async (req, res, next) => {
//   const { courseId } = req.body;
//   if (!courseId) return next(new AppError("Course ID is required", 400));
//   const newCert = await Certificate.create({ ...req.body, courseId });
//   res.status(201).json({ message: "created", data: newCert });
// });

// exports.deleteCertificate = catchAsync(async (req, res, next) => {
//   await Certificate.findByIdAndDelete(req.params.id);
//   res.status(204).json({ message: "deleted" });
// });
//latest 
const Certificate = require("../model/certificateModel");
const AppError = require("../utils/appError");
const { catchAsync } = require("../utils/catchAsync");
const { protect, restrictTo } = require("./authController");

exports.getAllCertificates = catchAsync(async (req, res, next) => {
  const certs = await Certificate.find();
  res.status(200).json({ message: "success", data: certs });
});

exports.createCertificate = catchAsync(async (req, res, next) => {
  const { courseId} = req.body;
  if (!courseId ) return next(new AppError("Course ID is required", 400));
  const newCert = await Certificate.create({ ...req.body, courseId, cer_issuedate: req.body.cer_issuedate || Date.now() });
  res.status(201).json({ message: "created", data: newCert });
});

exports.deleteCertificate = catchAsync(async (req, res, next) => {
  await Certificate.findByIdAndDelete(req.params.id);
  res.status(204).json({ message: "deleted" });
});
//newest 
// const Certificate = require("../model/certificateModel");
// const AppError = require("../utils/appError");
// const { catchAsync } = require("../utils/catchAsync");
// const { protect, restrictTo } = require("../controllers/authController");

// exports.getAllCertificates = catchAsync(async (req, res, next) => {
//   const certs = await Certificate.find();
//   res.status(200).json({ message: "success", data: certs });
// });

// exports.createCertificate = catchAsync(async (req, res, next) => {
//   const {courseId} = req.body;
//   if (!courseId ) return next(new AppError("Course ID is required", 400));
//   const newCert = await Certificate.create({ ...req.body, courseId, cer_issuedate: req.body.cer_issuedate || Date.now() });
//   res.status(201).json({ message: "created", data: newCert });
// });

// exports.deleteCertificate = catchAsync(async (req, res, next) => {
//   await Certificate.findByIdAndDelete(req.params.id);
//   res.status(204).json({ message: "deleted" });
// });