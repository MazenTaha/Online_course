const Enrollment = require("../model/enrollmentModel");
const AppError = require("../utils/appError");
const { catchAsync } = require("../utils/catchAsync");

exports.createEnrollment = catchAsync(async (req, res, next) => {
  const { courseId } = req.body;
  if (!courseId) return next(new AppError("Course ID is required", 400));
  const newEnrollment = await Enrollment.create({ ...req.body, studentId: req.user._id, courseId });
  res.status(201).json({ message: "Enrollment created successfully", data: newEnrollment });
});

exports.getAllEnrollments = catchAsync(async (req, res, next) => {
  const enrollments = await Enrollment.find();
  res.status(200).json({ message: "Enrollments fetched successfully", length: enrollments.length, data: enrollments });
});

exports.getEnrollmentById = catchAsync(async (req, res, next) => {
  const enrollment = await Enrollment.findById(req.params.id);
  if (!enrollment) return next(new AppError("Enrollment not found", 404));
  res.status(200).json({ message: "Enrollment fetched successfully", data: enrollment });
});
// exports.enrollStudent = catchAsync(async (req, res, next) => {
//   const enrollment = await Enrollment.create({
//     ...req.body,
//     studentId: req.params.studentId,
//   });

//   res.status(201).json({
//     message: "Student enrolled successfully",
//     data: enrollment,

//   });
exports.enrollStudent = catchAsync(async (req, res, next) => {
  const enrollment = await Enrollment.create({
    ...req.body,
    studentId: req.params.studentId,
  });

  res.status(201).json({
    message: "Student enrolled successfully",
    data: enrollment,
  });
});


exports.updateEnrollment = async (req, res) => {
  try {
    const enrollment = await Enrollment.findById(req.params.id);
    if (!enrollment) {
      return res.status(404).json({
        success: false,
        message: "Enrollment not found",
      });
    }
    const { status, grade } = req.body;
    if (status) enrollment.status = status;
    if (grade !== undefined) enrollment.grade = grade; // Allow null or number
    await enrollment.save();
    res.status(200).json({
      success: true,
      message: "Enrollment updated successfully",
      data: enrollment,
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: error.message,
    });
  }
};
// exports.enrollStudent = catchAsync(async (req, res, next) => {
//   const { courseId } = req.body;
//   if (!courseId) return next(new AppError("Course ID is required", 400));
//   const existingEnrollment = await Enrollment.findOne({ studentId: req.user._id, courseId });
//   if (existingEnrollment) return next(new AppError("Already enrolled", 400));
//   const newEnrollment = await Enrollment.create({ studentId: req.user._id, courseId, status: "active" });
//   res.status(201).json({ message: "Student enrolled successfully", data: newEnrollment });
// });