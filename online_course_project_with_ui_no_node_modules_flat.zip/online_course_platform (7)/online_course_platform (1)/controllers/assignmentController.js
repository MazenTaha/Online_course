const Assignment = require("../model/assignmentModel");
const AppError = require("../utils/appError");
const { catchAsync } = require("../utils/catchAsync");

exports.getAllAssignments = catchAsync(async (req, res, next) => {
  const assignments = await Assignment.find().populate("instructorIds");
  res.status(200).json({ message: "success", length: assignments.length, data: assignments });
});

exports.createAssignment = catchAsync(async (req, res, next) => {
  const newAssignment = await Assignment.create({ ...req.body, instructorIds: [req.user._id] });
  res.status(201).json({ message: "success", data: newAssignment });
});

exports.getAssignmentById = catchAsync(async (req, res, next) => {
  const assignment = await Assignment.findById(req.params.id).populate("instructorIds");
  if (!assignment) return next(new AppError("Assignment not found", 404));
  res.status(200).json({ message: "The assignment returned", data: assignment });
});

exports.updateAssignment = catchAsync(async (req, res, next) => {
  const updateAssignment = await Assignment.findOneAndUpdate({ _id: req.params.id }, req.body, { new: true });
  if (!updateAssignment) return next(new AppError("Assignment not found to update", 404));
  res.status(200).json({ message: "Assignment updated successfully", data: updateAssignment });
});

exports.deleteAssignment = catchAsync(async (req, res, next) => {
  const assignmentExists = await Assignment.findById(req.params.id);
  if (!assignmentExists) return next(new AppError("Assignment not found", 404));
  await Assignment.findByIdAndDelete(req.params.id);
  res.status(204).json();
});

exports.validateAssignment = (req, res, next) => {
  const { title, dueDate } = req.body;
  if (!title || !dueDate) return next(new AppError("Missing required fields: title and dueDate", 400));
  next();
};