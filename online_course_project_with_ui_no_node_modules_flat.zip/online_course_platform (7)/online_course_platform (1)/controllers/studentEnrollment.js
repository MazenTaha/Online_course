// const enrollment = require('../model/enrollmentModel');
// const User = require('../model/userModel');
// const Course = require('../model/courseModel');
// const AppError = require("../utils/appError");
// const { catchAsync } = require("../utils/catchAsync");

// exports.studentEnrollEnrollments = catchAsync(async (req, res, next) => {
//   const { courseId } = req.body;
//   if (!courseId) {
//     return next(new AppError("Missing required field: courseId", 400));
//   }
//   if (!req.user || req.user.role !== 'student') {
//     return next(new AppError( 403));
//   }
//   const course = await Course.findById(courseId);
//   if (!course) {
//     return next(new AppError("Course not found", 404));
//   }
//   const enrollment = await Enrollment.create({
//     studentId: req.user.id,
//     courseId: courseId,
//   });
//   res.status(201).json({
//     message: "Student enrolled successfully",
//     data: enrollment,
//   });
// });

//latest
// 

//new 
// const Enrollment = require('../model/enrollmentModel');
// const User = require('../model/userModel');
// const Course = require('../model/courseModel');
// const AppError = require("../utils/appError");
// const { catchAsync } = require("../utils/catchAsync");
// const crypto = require("crypto"); // For generating unique IDs

// exports.studentEnrollEnrollments = catchAsync(async (req, res, next) => {
//   const { courseId } = req.body;

//   // 1. Validate request
//   if (!courseId) {
//     return next(new AppError("Missing required field: courseId", 400));
//   }

//   // 2. Ensure user is a student
//   if (!req.user || req.user.role !== 'student') {
//     return next(new AppError("Only students can enroll in courses", 403));
//   }

//   // 3. Check if course exists
//   const course = await Course.findById(courseId);
//   if (!course) {
//     return next(new AppError("Course not found", 404));
//   }

//   // 4. Prevent duplicate enrollment
//   const existingEnrollment = await Enrollment.findOne({
//     studentId: req.user.id,
//     courseId: courseId
//   });
//   if (existingEnrollment) {
//     return next(new AppError("You are already enrolled in this course", 400));
//   }

//   // 5. Generate unique enrollment_id
//   const enrollmentId = `ENR-${crypto.randomBytes(4).toString("hex").toUpperCase()}`;

//   // 6. Create enrollment
//   const enrollment = await Enrollment.create({
//     enrollment_id: enrollmentId,
//     status: "in-progress", // Default as per schema
//     grade: null, // No grade at enrollment
//     studentId: req.user.id,
//     courseId: courseId
//   });

//   res.status(201).json({
//     status: "success",
//     message: "Student enrolled successfully",
//     data: enrollment,
//   });
// });
//last edit 
// controllers/enrollmentController.js
// const Enrollment = require("../model/enrollmentModel");

// // Create new enrollment (auto-generate enrollment_id)
// exports.createEnrollment = async (req, res) => {
//   try {
//     // Generate an ID like ENR1234
//     const enrollmentId = "ENR" + Math.floor(1000 + Math.random() * 9000);

//     const enrollment = await Enrollment.create({
//       enrollment_id: enrollmentId,
//       courseId: req.body.courseId,
//       studentId: req.user._id, // assuming you have auth middleware that sets req.user
//     });

//     res.status(201).json({
//       success: true,
//       message: "Enrollment created successfully",
//       data: enrollment,
//     });
//   } catch (error) {
//     res.status(400).json({
//       success: false,
//       message: error.message,
//     });
//   }
// };

// // Get all enrollments
// exports.getAllEnrollments = async (req, res) => {
//   try {
//     const enrollments = await Enrollment.find().populate("courseId").populate("studentId");
//     res.status(200).json({
//       success: true,
//       data: enrollments,
//     });
//   } catch (error) {
//     res.status(500).json({
//       success: false,
//       message: error.message,
//     });
//   }
// };
//last 
// const Enrollment = require("../model/enrollmentModel");

// // Create new enrollment (auto-generate enrollment_id)
// exports.createEnrollment = async (req, res) => {
//   try {
//     const { courseId } = req.body;
//     if (!courseId) {
//       return res.status(400).json({
//         success: false,
//         message: "Course ID is required",
//       });
//     }

//     // Check if student is already enrolled in this course
//     const existingEnrollment = await Enrollment.findOne({
//       courseId,
//       studentId: req.user._id,
//     });

//     if (existingEnrollment) {
//       return res.status(400).json({
//         success: false,
//         message: "You are already enrolled in this course",
//       });
//     }

//     // Generate an ID like ENR1234
//     const enrollmentId = "ENR" + Math.floor(1000 + Math.random() * 9000);

//     // const enrollment = await Enrollment.create({
//     //   enrollment_id: enrollmentId,
//     //   courseId,
//     //   studentId: req.user._id, // from auth middleware
//     // });
//     const enrollment = await Enrollment.findOne({
//   studentId: studentId,
//   courseId: courseId
// });


//     res.status(201).json({
//       success: true,
//       message: "Enrollment created successfully",
//       data: enrollment,
//     });
//   } catch (error) {
//     res.status(400).json({
//       success: false,
//       message: error.message,
//     });
//   }
// };

// // Get all enrollments
// exports.getAllEnrollments = async (req, res) => {
//   try {
//     const enrollments = await Enrollment.find()
//       .populate("courseId")
//       .populate("studentId");
//     res.status(200).json({
//       success: true,
//       data: enrollments,
//     });
//   } catch (error) {
//     res.status(500).json({
//       success: false,
//       message: error.message,
//     });
//   }
// };
// ----
const Enrollment = require("../model/enrollmentModel");

exports.createEnrollment = async (req, res) => {
  try {
    const { courseId } = req.body;
    if (!courseId) {
      return res.status(400).json({
        success: false,
        message: "Course ID is required",
      });
    }

    const existingEnrollment = await Enrollment.findOne({
      courseId,
      studentId: req.user._id,
    });

    if (existingEnrollment) {
      return res.status(400).json({
        success: false,
        message: "You are already enrolled in this course",
      });
    }

    const enrollmentId = "ENR" + Math.floor(1000 + Math.random() * 9000);

    const enrollment = await Enrollment.create({
      enrollment_id: enrollmentId,
      courseId,
      studentId: req.user._id,
    });

    res.status(201).json({
      success: true,
      message: "Enrollment created successfully",
      data: enrollment,
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: error.message,
    });
  }
};

exports.getAllEnrollments = async (req, res) => {
  try {
    const enrollments = await Enrollment.find()
      .populate("courseId")
      .populate("studentId");
    res.status(200).json({
      success: true,
      data: enrollments,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};