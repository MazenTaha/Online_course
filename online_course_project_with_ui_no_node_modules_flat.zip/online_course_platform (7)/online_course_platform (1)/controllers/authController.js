const User = require("../model/userModel");
const AppError = require("../utils/appError");
const { catchAsync } = require("../utils/catchAsync");
const jwt = require("jsonwebtoken");

const signToken = (payload) => {
  return jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN });
};
exports.signToken = signToken;

exports.signUp = catchAsync(async (req, res, next) => {
  const { firstName, lastName, email, username, password, phone, age, gender, role } = req.body;
  const newUser = await User.create({ 
    firstName, 
    lastName, 
    email, 
    username, 
    password, 
    phone, 
    age, 
    gender, 
    role: role //|| "student" // Default to student
  });
  const token = signToken({ id: newUser._id, role: newUser.role });
  res.status(201).json({ message: "success", data: newUser, token });
});

exports.login = catchAsync(async (req, res, next) => {
  const { email, password } = req.body;
  if (!email || !password) return next(new AppError("Please provide email and password", 400));
  const user = await User.findOne({ email }).select("+password");
  if (!user || !(await user.correctPassword(password))) return next(new AppError("Incorrect email or password", 401));
  const token = signToken({ id: user._id, role: user.role });
  res.status(200).json({ message: "success", token });
});

exports.protect = catchAsync(async (req, res, next) => {
  const authHeader = req.headers["authorization"] || req.headers["Authorization"];
  if (!authHeader || !authHeader.startsWith("Bearer")) 
    return next(new AppError("You are not logged in! Please log in to get access", 401));
  const token = authHeader.split(" ")[1];
  let decode;
  try {
    decode = jwt.verify(token, process.env.JWT_SECRET);
  } catch (err) {
    return next(new AppError("Invalid token! Please log in again", 401));
  }
  const user = await User.findById(decode.id);
  if (!user) return next(new AppError("User no longer exists", 404));
  req.user = user;
  next();
});

exports.restrictTo = (...roles) => {
  return (req, res, next) => {
    if (!roles.includes(req.user.role)) return next(new AppError("You do not have permission to perform this action", 403));
    next();
  };
};