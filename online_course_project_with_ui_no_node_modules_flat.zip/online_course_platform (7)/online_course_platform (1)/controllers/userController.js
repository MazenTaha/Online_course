const User = require("../model/userModel");
const AppError = require("../utils/appError");
const { catchAsync } = require("../utils/catchAsync");
const ApiFilters = require("../utils/apiFilter");

exports.getAllUsers = catchAsync(async (req, res, next) => {
  const filter = new ApiFilters(User.find(), req.query).filter().sort().fields().pagination();
  const users = await filter.query;
  res.status(200).json({ message: "Users fetched successfully", length: users.length, data: users });
});

exports.getUserById = catchAsync(async (req, res, next) => {
  const user = await User.findById(req.params.id);
  if (!user) return next(new AppError("User not found", 404));
  res.status(200).json({ message: "User fetched successfully", data: user });
});

exports.createUser = catchAsync(async (req, res, next) => {
  const { firstName, lastName, email, username, password, phone, age, gender } = req.body;
  const newUser = await User.create({ firstName, lastName, email, username, password, phone, age, gender });
  res.status(201).json({ message: "User created successfully", data: newUser });
});

exports.deleteUser = catchAsync(async (req, res, next) => {
  const userExists = await User.findById(req.params.id);
  if (!userExists) return next(new AppError("User not found", 404));
  await User.findByIdAndDelete(req.params.id);
  res.status(204).json();
});

exports.updateUser = catchAsync(async (req, res, next) => {
  const userExists = await User.findById(req.params.id);
  if (!userExists) return next(new AppError("User not found", 404));
  const updateUser = await User.findOneAndUpdate({ _id: req.params.id }, req.body, { new: true });
  if (!updateUser) return next(new AppError("User not found to update", 404));
  res.status(200).json({ message: "User updated successfully", data: updateUser });
});