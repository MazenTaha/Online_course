const mongoose = require("mongoose");

const courseSchema = new mongoose.Schema({
  course_id: {
    type: String,
    required: true,
    unique: true,
  },
  course_title: {
    type: String,
    required: true,
  },
  instructorId: {
    type: mongoose.Schema.ObjectId,
    ref: "User",
    required: true,
  },
  course_creationdate: {
    type: Date,
    default: Date.now,
  },
  category: {
    type: String,
  },
}, {
  toJSON: { virtuals: true },
  toObject: { virtuals: true },
  timestamps: true,
});

const Course = mongoose.model("Course", courseSchema);
module.exports = Course;