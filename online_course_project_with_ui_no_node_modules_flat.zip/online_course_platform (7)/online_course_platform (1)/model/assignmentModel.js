const mongoose = require("mongoose");

const assignmentSchema = new mongoose.Schema(
  {
    instructorIds: [{
      type: mongoose.Schema.ObjectId,
      ref: "User",
    }],
    title: {
      type: String,
      required: true,
    },
    description: {
      type: String,
    },
    dueDate: {
      type: Date,
      required: true,
    },
    attachments: [{
      type: String,
    }],
  },
  {
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
    timestamps: true,
  }
);

assignmentSchema.virtual("students", {
  ref: "User",
  localField: "_id",
  foreignField: "assignments", // Assumed relationship
});

const Assignment = mongoose.model("Assignment", assignmentSchema);
module.exports = Assignment;