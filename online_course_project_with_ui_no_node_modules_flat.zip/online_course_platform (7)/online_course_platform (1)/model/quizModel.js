const mongoose = require("mongoose");

const quizSchema = new mongoose.Schema(
  {
    studentId: {
      type: mongoose.Schema.ObjectId,
      ref: "User",
      required: true,
    },
    instructorIds: [{
          type: mongoose.Schema.ObjectId,
          ref: "User",
        }],
    // instructorId: {
    //   type: mongoose.Schema.ObjectId,
    //   ref: "User",
    //   required: true,
    // },
    title: {
      type: String,
      required: true,
    },
    description: {
      type: String,
    },
    questions: [
      {
        questionText: { type: String, required: true },
        options: { type: [String], required: true, validate: { validator: (v) => v.length > 1, message: "Options must contain at least 2 items" } },
        correctAnswer: { type: String, required: true },
      },
    ],
    timeLimit: {
      type: Number,
      min: [1, "Time limit must be at least 1 minute"],
      default: 30,
    },
  },
  {
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
    timestamps: true,
  }
);

quizSchema.virtual("student", {
  ref: "User",
  foreignField: "_id",
  localField: "studentId",
});

const Quiz = mongoose.model("Quiz", quizSchema);
module.exports = Quiz;