// const mongoose = require("mongoose");

// const certificateSchema = new mongoose.Schema({
//   cer_id: {
//     type: String,
//     required: true,
//     unique: true,
//   },
//   userId: {
//     type: mongoose.Schema.ObjectId,
//     ref: "User",
//     required: true,
//   },
//   courseId: {
//     type: mongoose.Schema.ObjectId,
//     ref: "Course",
//     required: true,
//   },
//   cer_issuedate: {
//     type: Date,
//     default: Date.now,
//   },
//   issued_by: {
//     type: String,
//     required: true,
//   },
// }, {
//   toJSON: { virtuals: true },
//   toObject: { virtuals: true },
//   timestamps: true,
// });

// const Certificate = mongoose.model("Certificate", certificateSchema);
// module.exports = Certificate;
// ---------------
// const mongoose = require("mongoose");

// const certificateSchema = new mongoose.Schema({
//   // cer_id: {
//   //   type: String,
//   //   required: false,
//   //   unique: true,
//   // },
//   // userId: {
//   //   type: mongoose.Schema.ObjectId,
//   //   ref: "User",
//   //   required: false, // Changed to false for optional assignment
//   // },
//   courseId: {
//     type: mongoose.Schema.ObjectId,
//     ref: "Course",
//     required: true,
//   },
//   cer_issuedate: {
//     type: Date,
//     default: Date.now,
//   },
//   // issued_by: {
//   //   type: String,
//   //   required: false,
//   // },
// }, {
//   toJSON: { virtuals: true },
//   toObject: { virtuals: true },
//   timestamps: true,
// });

// const Certificate = mongoose.model("Certificate", certificateSchema);
// module.exports = Certificate;

// //new
// // const mongoose = require("mongoose");

// // const certificateSchema = new mongoose.Schema({
// //   cer_id: {
// //     type: String,
// //     unique: true,
// //     required: true
// //   },
// //   studentId: {
// //     type: mongoose.Schema.ObjectId,
// //     ref: "User",
// //     required: false
// //   },
// //   courseId: {
// //     type: mongoose.Schema.ObjectId,
// //     ref: "Course",
// //     required: true
// //   },
// //   dateIssued: {
// //     type: Date,
// //     default: Date.now
// //   }
// // });

// // // Generate a unique cer_id before saving
// // certificateSchema.pre("save", function (next) {
// //   if (!this.cer_id) {
// //     // Format: CER + Timestamp + Random 3 digits
// //     this.cer_id = "CER" + Date.now() + Math.floor(Math.random() * 1000);
// //   }
// //   next();
// // });

// // module.exports = mongoose.model("Certificate", certificateSchema);


// -----
const mongoose = require("mongoose");

const certificateSchema = new mongoose.Schema({
  cer_id: {
    type: String,
    required: false,
    default: () => `CERT_${Date.now()}_${Math.floor(Math.random() * 1000)}`, // Unique default
  },
  courseId: {
    type: mongoose.Schema.ObjectId,
    ref: "Course",
    required: true,
  },
  cer_issuedate: {
    type: Date,
    default: Date.now,
  },
}, {
  toJSON: { virtuals: true },
  toObject: { virtuals: true },
  timestamps: true,
});

const Certificate = mongoose.model("Certificate", certificateSchema);
module.exports = Certificate;