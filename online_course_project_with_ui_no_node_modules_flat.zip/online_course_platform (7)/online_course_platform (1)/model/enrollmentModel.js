const mongoose = require("mongoose");
const validator = require("validator");

const enrollmentSchema = new mongoose.Schema({
  enrollment_id: {
    type: String,
    required: [true, "Please provide enrollment ID"],
    unique: true,
    trim: true,
    validate: {
      validator: (val) => validator.isAlphanumeric(val),
      message: "Enrollment ID must be alphanumeric",
    },
    minlength: [5, "Enrollment ID must be at least 5 characters"],
    maxlength: [20, "Enrollment ID must not exceed 20 characters"],
  },
  enrollment_time: {
    type: Date,
    default: Date.now,
    required: [true, "Please provide enrollment time"],
  },
  status: {
    type: String,
    enum: ["active", "inactive"],
    default: "active",
    required: [true, "Please provide enrollment status"],
  }, 

  status: {
  type: String,
  enum: ['in-progress', 'completed'],
  default: 'in-progress',
  },

grade: {
  type: Number, // Represents percentage out of 100
  min: 0,
  max: 100,
},
  studentId: {
    type: mongoose.Schema.ObjectId,
    ref: "User",
    required: true,
  },
  courseId: {
    type: mongoose.Schema.ObjectId,
    ref: "Course",
    required: true,
  },
});

module.exports = mongoose.model("Enrollment", enrollmentSchema);