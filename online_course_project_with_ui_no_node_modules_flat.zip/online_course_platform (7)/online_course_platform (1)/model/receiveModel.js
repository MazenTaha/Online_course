const mongoose = require("mongoose");

const receiveSchema = new mongoose.Schema({
  received_at: {
    type: Date,
    default: Date.now,
    validate: {
      validator: function (v) {
        return v <= Date.now();
      },
      message: "Received date cannot be in the future",
    },
  },
  student: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: true,
  },
  certificate: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Certificate",
    required: true,
  },
}, {
  toJSON: { virtuals: true },
  toObject: { virtuals: true },
  timestamps: true,
});

receiveSchema.virtual("studentDetails", {
  ref: "User",
  foreignField: "_id",
  localField: "student",
});

receiveSchema.virtual("certificateDetails", {
  ref: "Certificate",
  foreignField: "_id",
  localField: "certificate",
});

module.exports = mongoose.model("Receive", receiveSchema);