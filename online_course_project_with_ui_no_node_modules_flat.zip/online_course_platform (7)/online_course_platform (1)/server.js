const app = require("./app");
const dotenv = require("dotenv");
const mongoose = require("mongoose");

dotenv.config({ path: "./.env" });

const PortNumber = process.env.PORT || 3000;

const dbAtlasString = process.env.DB.replace("<db_password>", process.env.DB_PASSWORD);

mongoose.connect(dbAtlasString)
  .then(() => console.log("DB connection successful"))
  .catch(err => {
    console.error("DB connection error:", err.message);
    process.exit(1);
  });

mongoose.connection.on("error", err => {
  console.error("MongoDB connection error:", err);
  process.exit(1);
});

const server = app.listen(PortNumber, () => console.log(`Server running on port ${PortNumber}`));

server.on("error", (err) => {
  console.error("Server error:", err.message);
  process.exit(1);
});

process.on("unhandledRejection", (err) => {
  console.error("Unhandled Rejection:", err);
  server.close(() => process.exit(1));
});